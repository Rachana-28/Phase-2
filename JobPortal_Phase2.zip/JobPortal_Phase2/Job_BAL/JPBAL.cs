﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Job_DAL;
using Job_Exception;
using System.Data;
using System.Text.RegularExpressions;

namespace Job_BAL
{
    public class JPBAL
    {
        public static bool ValidateUser(UserEntities user)  //To validate User Entities
        {
            bool validateUser = true;
            try
            {
                //if (!Regex.IsMatch(user.UserID, @"[0-9]{5}"))
                //{
                //    validateUser = false;
                //    throw new JobExceptions("Id should be of length 5");
                //}
                //if (!Regex.IsMatch(user.Password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"))
                //{
                //    validateUser = false;
                //    throw new JPException("Password must contain one upper case alphabet one lower case alphabet one special character and one numeric value atleast with minimum length of 8");
                //}
                if (user.Age < 18)
                {
                    validateUser = false;
                    throw new JobExceptions("Age must be greater than 18");

                }
                if (user.Gender != "M" && user.Gender != "F")
                {
                    validateUser = false;
                    throw new JobExceptions("Gender should be M or F");
                }
                //if (user.UserType != "A" && user.UserType != "U")
                //{
                //    validateUser = false;
                //    throw new JobExceptions("UserType should be A or U");
                //}
                if ( user.Password == String.Empty || user.FirstName == String.Empty || user.LastName == String.Empty || user.Age.ToString() == String.Empty || user.Gender == String.Empty || user.Address == String.Empty || user.PhoneNo == String.Empty )
                {
                    validateUser = false;
                    throw new JobExceptions("ALL FIELDS ARE MANDATORY");
                }

            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validateUser;
        }

        public static bool ValidateJob(JobEntities job) //To validate Admin Entities
        {
            bool validateJob = true;
            try
            {
                //if (!Regex.IsMatch(job.JobID, @"[0-9]{5}"))
                //{
                //    validateJob = false;
                //    throw new JobExceptions("Id should be of length 5");
                //}
                if (!Regex.IsMatch(job.ContactNumber, @"[6-9][0-9]{9}"))
                {
                    validateJob = false;
                    throw new JobExceptions("Contact number must be of ten digits");
                }
                //if (!Regex.IsMatch(job.ContactEmailID, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"))
                //{
                //    validateJob = false;
                //    throw new JPException("Input must be of Email type");
                //}
                if (job.Salary < 0)
                {
                    validateJob = false;
                    throw new JobExceptions("Salary must be positive");

                }
                if ( job.Employer == String.Empty || job.Address == String.Empty || job.ContactNumber == String.Empty || job.ContactEmailID == String.Empty || job.SkillsRequired == String.Empty || job.Qualification == String.Empty || job.Location == String.Empty || job.Salary.ToString() == String.Empty || job.NoOfVacancies.ToString() == String.Empty)
                {
                    validateJob = false;
                    throw new JobExceptions("ALL FIELDS ARE MANDATORY");
                }

            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validateJob;
        }

        public static bool AddUserBL(UserEntities user)//To new user
        {
            bool userAdded = false;
            try
            {
                if (ValidateUser(user))
                {
                    JPDAL jobDAL = new JPDAL();
                    userAdded = jobDAL.AddUserDAL(user);
                    return userAdded;
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userAdded;
        }

        public static bool AddJobBL(JobEntities job)//To Add new job
        {
            bool jobAdded = false;
            try
            {
                if (ValidateJob(job))
                {
                    JPDAL jobDAL = new JPDAL();
                    jobAdded = jobDAL.AddJobDAL(job);
                    return jobAdded;
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobAdded;
        }

        public static bool EditJobBL(JobEntities job)   //Admin to Edit Job
        {
            bool jobUpdated = false;
            try
            {
                if (ValidateJob(job))
                {
                    JPDAL jobDAL = new JPDAL();
                    jobUpdated = jobDAL.EditJobDAL(job);
                    return jobUpdated;
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobUpdated;
        }

        public static bool DeleteJobBL(int JobID)   //Admin to delete job
        {
            bool isJobDeleted = false;
            try
            {
                JPDAL jobDAL = new JPDAL();
                isJobDeleted = jobDAL.DeleteJobDAL(JobID);
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            return isJobDeleted;
        }

        public static JobEntities SearchJobBL(int yoe,string jobname)    //user to search jobs by id
        {
            JobEntities job = null;
            try
            {
                JPDAL jobDAL = new JPDAL();
                job = jobDAL.SearchJobDAL(yoe,jobname);
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return job;
        }
        public static JobEntities SearchAdminJobBL(int jobid)    //Admin to search jobs by id
        {
            JobEntities job = null;
            try
            {
                JPDAL jobDAL = new JPDAL();
                job = jobDAL.SearchAdminJobDAL(jobid);
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return job;
        }

        public static List<JobEntities> GetAllJobBL()   //to get all jobs for users and admin
        {
            List<JobEntities> jobList;
            try
            {
               JPDAL jobDAL = new JPDAL();
                jobList = jobDAL.GetAllJobDAL();
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobList;
        }
        public static bool ValidateUserBL(int id,string password)
        {
            bool validate = false;
            try
            {
                
                JPDAL jobDAL = new JPDAL();
                validate = jobDAL.User(id, password);
                    
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            return validate;

        }


    }
}
