﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job_Exception
{
    public class JobExceptions:ApplicationException
    {
        public JobExceptions() : base()
        {

        }

        public JobExceptions(string message) : base(message)
        {

        }

        public JobExceptions(string message, Exception innerException)
            : base(innerException: innerException, message: message)
        {

        }
    }
}
