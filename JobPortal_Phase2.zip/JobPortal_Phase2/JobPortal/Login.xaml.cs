﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

       

       
        private void ClickToLogin(object sender, RoutedEventArgs e)
        {
            UserEntities objUserEntities = new UserEntities();
            JobEntities objJobEntities = new JobEntities();
            //objUserEntities.UserID = txtLoginid.Text;
            //objUserEntities.Password = txtPassword.Text;
            //objJobEntities.AdminID = txtLoginid.Text;
            //objJobEntities.AdminPassword = txtPassword.Text;
           if(rb_Admin.IsChecked==true)
            {
                string Login;
                string password;
                Login = txtLoginid.Text;
                password = txtPassword.Text;
                if(objJobEntities.AdminID==Login&&objJobEntities.AdminPassword==password)
                {
                    Admin a = new Admin();
                    this.Hide();
                    a.ShowDialog();
                    
                }
                else
                {
                    MessageBox.Show("UserId or Password is not correct");
                }



            }
           if(rb_User.IsChecked==true)
            {
                int Login;
                string password;
                Login = Convert.ToInt32(txtLoginid.Text);
                password = txtPassword.Text;
                bool log = JPBAL.ValidateUserBL(Login, password);
               if(log)
                {
                    Search s = new Search();
                    this.Hide();
                    s.ShowDialog();
                }
                else
                {
                    MessageBox.Show("UserId or Password is not correct");
                }


            }
            
           




        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Rb_User_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
