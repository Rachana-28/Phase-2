﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for EditJob.xaml
    /// </summary>
    public partial class EditJob : Window
    {
        public EditJob()
        {
            InitializeComponent();
        }
        

        private void Back(object sender, RoutedEventArgs e)
        {

        }

        

        
        private void UpdateJob()
        {
            try
            {
                string JobName;
                string Employer;
                string Address;
                string ContactNumber;
                string ContactEmailID;
                string SkillsRequired;
                string Qualification;
                string Location;
                long Salary;
                int NoOfVacancies;
                int YearsOfExperience;
                //
                bool jobUpdated;
                //
                JobName = txtJobName.Text;
                Employer = txtEmployer.Text;
                Address = txtAddress.Text;
                ContactNumber = txtContactNumber.Text;
                ContactEmailID = txtContactEmailID.Text;
                SkillsRequired = txtSkillsRequired.Text;
                Qualification = txtQualification.Text;
                Location = txtLocation.Text;
                NoOfVacancies = Convert.ToInt32(txtNoOfVacancies.Text);
                Salary = Convert.ToInt64(txtNoOfVacancies.Text);
                YearsOfExperience = Convert.ToInt32(txtYearsOfExperience.Text);
                //
                JobEntities objJobEntities = new JobEntities()
                {
                    JobName = JobName,
                    Employer = Employer,
                    Address = Address,
                    ContactNumber = ContactNumber,
                    ContactEmailID = ContactEmailID,
                    SkillsRequired = SkillsRequired,
                    Qualification = Qualification,
                    Location = Location,
                    NoOfVacancies = NoOfVacancies,
                    Salary = Salary,
                    YearsOfExperience=YearsOfExperience

                };
                jobUpdated = JPBAL.EditJobBL(objJobEntities);
                if (jobUpdated == true)
                {
                    MessageBox.Show("Employee record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be updated.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void SearchJob()
        {
            try
            {
                int JobID;
                //
                JobEntities objJobEntities;
                //
                JobID = Convert.ToInt32(txtJobID.Text);
                //
                objJobEntities = JPBAL.SearchAdminJobBL(JobID);
                if (objJobEntities != null)
                {
                    txtJobName.Text = objJobEntities.JobName;
                    txtEmployer.Text = objJobEntities.Employer;
                    txtAddress.Text = objJobEntities.Address;
                    txtContactNumber.Text = objJobEntities.ContactNumber;
                    txtContactEmailID.Text = objJobEntities.ContactEmailID;
                    txtSkillsRequired.Text = objJobEntities.SkillsRequired;
                    txtLocation.Text = objJobEntities.Location;
                    txtQualification.Text = objJobEntities.Qualification;
                    txtNoOfVacancies.Text = objJobEntities.NoOfVacancies.ToString();
                    txtSalary.Text = objJobEntities.Salary.ToString();
                    txtYearsOfExperience.Text = objJobEntities.YearsOfExperience.ToString();
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void UpdatingJob(object sender, RoutedEventArgs e)
        {
            UpdateJob();

        }

        private void clearing(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            txtJobID.Clear();
            txtEmployer.Clear();
            txtJobName.Clear();
            txtAddress.Clear();
            txtContactEmailID.Clear();
            txtContactNumber.Clear();
            txtLocation.Clear();
            txtNoOfVacancies.Clear();
            txtQualification.Clear();
            txtSkillsRequired.Clear();
            txtYearsOfExperience.Clear();
            txtSalary.Clear();
            

        }

        private void Search(object sender, RoutedEventArgs e)
        {
            SearchJob();
        }
    }
}
