﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for JobList.xaml
    /// </summary>
    public partial class JobList : Window
    {
        public JobList()
        {
            InitializeComponent();
            GetJobs();
            
        }
        private void GetJobs()
        {
            try
            {
                List<JobEntities> objJobEntites = JPBAL.GetAllJobBL();
                if (objJobEntites != null)
                {
                    dgjobs.ItemsSource = objJobEntites;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
                catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
