﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void Searching(object sender, RoutedEventArgs e)
        {
            SearchJob();
        }
        private void SearchJob()
        {
            try
            {
                int YearsOfExperience;
                string JobName;
                //
               
                //
                YearsOfExperience = Convert.ToInt32(txtYearsOfExperience.Text);
                JobName = txtJobName.Text;
                //
                if (YearsOfExperience != 0 && JobName != null)
                {
                    //JobEntities objJobEntities = JPBAL.SearchJobBL(YearsOfExperience, JobName);


                    List<JobEntities> objJobs = JPBAL.GetAllJobBL();
                    if (objJobs != null)
                    {
                        dgjobs.ItemsSource = objJobs;
                    }
                    else
                    {
                        MessageBox.Show("No records available.");
                    }

                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
