﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void AddJob(object sender, RoutedEventArgs e)
        {
            AddJob aj = new AddJob();
            this.Hide();
            aj.ShowDialog();

        }

        private void EditJob(object sender, RoutedEventArgs e)
        {
            EditJob ej = new EditJob();
            this.Hide();
            ej.ShowDialog();

            
        }

        private void DeleteJob(object sender, RoutedEventArgs e)
        {
            DeleteJob dj = new DeleteJob();
            this.Hide();
            dj.ShowDialog();
        }

        private void GetJob(object sender, RoutedEventArgs e)
        {
            JobList jl = new JobList();
            this.Hide();
            jl.ShowDialog();

        }
    }
}
