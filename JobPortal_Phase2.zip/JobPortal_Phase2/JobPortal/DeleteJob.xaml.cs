﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for DeleteJob.xaml
    /// </summary>
    public partial class DeleteJob : Window
    {
        public DeleteJob()
        {
            InitializeComponent();
        }

        private void DeletingJob(object sender, RoutedEventArgs e)
        {
            try
            {

                int JobID;
                //
                bool employeeDeleted;
                //
                
                JobID = Convert.ToInt32(txtJobID.Text);
                //
                employeeDeleted = JPBAL.DeleteJobBL(JobID);
                if (employeeDeleted == true)
                {
                    MessageBox.Show("Job record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Job record couldn't be Find.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
