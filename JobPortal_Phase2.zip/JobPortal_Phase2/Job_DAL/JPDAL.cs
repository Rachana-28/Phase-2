﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Job_Exception;
using Entities;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Job_DAL
{
    public class JPDAL
    {
        SqlDataReader objDR;
        public bool AddUserDAL(UserEntities objUserEntities)//new user
        {
            bool userAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_UserInsert]", objCon);//chnage
                objCom.CommandType = CommandType.StoredProcedure;
                //
                
                SqlParameter objSqlParam_Password = new SqlParameter("@Password", objUserEntities.Password);
                SqlParameter objSqlParam_FirstName = new SqlParameter("@FirstName", objUserEntities.FirstName);
                SqlParameter objSqlParam_LastName = new SqlParameter("@LastName", objUserEntities.LastName);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objUserEntities.Address);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objUserEntities.Age);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objUserEntities.Gender);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objUserEntities.PhoneNo);
          



                //

                objCom.Parameters.Add(objSqlParam_Password);
                objCom.Parameters.Add(objSqlParam_FirstName);
                objCom.Parameters.Add(objSqlParam_LastName);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_Age);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_PhoneNo);
                
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                userAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return userAdded;
        }
        public bool AddJobDAL(JobEntities objJobEntities)//admin adds jobdetails
        {
            bool jobAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobInsert]", objCon);//chnage
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_JobName = new SqlParameter("@JobName", objJobEntities.JobName);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", objJobEntities.Employer);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", objJobEntities.Location);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", objJobEntities.Salary);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objJobEntities.Address);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", objJobEntities.ContactNumber);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", objJobEntities.ContactEmailID);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", objJobEntities.SkillsRequired);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", objJobEntities.Qualification);
                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", objJobEntities.NoOfVacancies);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", objJobEntities.YearsOfExperience);
                

                //
                
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_NoOfVaccancies);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                objCom.Parameters.Add(objSqlParam_JobName);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                jobAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobAdded;
        }

        public bool EditJobDAL(JobEntities objJobEntities)  //admin edits job details
        {
            bool jobUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobEdit]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_JobName = new SqlParameter("@JobName", objJobEntities.JobName);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", objJobEntities.Employer);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", objJobEntities.Location);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", objJobEntities.Salary);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objJobEntities.Address);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", objJobEntities.ContactNumber);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", objJobEntities.ContactEmailID);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", objJobEntities.SkillsRequired);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", objJobEntities.Qualification);
                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", objJobEntities.NoOfVacancies);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", objJobEntities.YearsOfExperience);
                //
                objCom.Parameters.Add(objSqlParam_JobName);
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                jobUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobUpdated;
        }

        public bool DeleteJobDAL(int JobID)    //admin deletes job by id
        {
            bool jobDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobDelete]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParameter_JobID = new SqlParameter("@JobID", JobID);

                //
                objCom.Parameters.Add(objSqlParameter_JobID);

                //
                objCon.Open();
                int num = objCom.ExecuteNonQuery();
                if (num != 0)
                {
                    jobDeleted = true;
                }
        }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobDeleted;
        }

        public JobEntities SearchJobDAL(int yoe,string jobname)  //user Search Job by years of experience and name
        {
            JobEntities objJobEntities = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_SearchJob]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParameter_JobName = new SqlParameter("@JobName", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", SqlDbType.VarChar, 50);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", SqlDbType.VarChar, 50);

                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", SqlDbType.Int);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", SqlDbType.Int);

                //
                objSqlParameter_JobName.Direction = ParameterDirection.Input;
                objSqlParam_Employer.Direction = ParameterDirection.Output;
                objSqlParam_Location.Direction = ParameterDirection.Output;
                objSqlParam_Salary.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_ContactNumber.Direction = ParameterDirection.Output;
                objSqlParam_ContactEmailId.Direction = ParameterDirection.Output;
                objSqlParam_SkillsRequired.Direction = ParameterDirection.Output;
                objSqlParam_Qualification.Direction = ParameterDirection.Output;
                objSqlParam_NoOfVaccancies.Direction = ParameterDirection.Output;
                objSqlParam_YearsOfExperience.Direction = ParameterDirection.Input; 
                //
               
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                //
               
                //
               // objCon.Open();
               // objCom.ExecuteNonQuery();
               // objJobEntities = new JobEntities();
               //// objJobEntities.JobID = id;
               // objJobEntities.JobName = objSqlParameter_JobName.Value as string;
               // objJobEntities.Employer = objSqlParam_Employer.Value as string;
               // objJobEntities.Location = objSqlParam_Location.Value as string;
               // objJobEntities.Salary = Convert.ToInt32(objSqlParam_Salary.Value);
               // objJobEntities.Address = objSqlParam_Address.Value as string;
               // objJobEntities.ContactNumber = objSqlParam_ContactNumber.Value as string;
               // objJobEntities.ContactEmailID = objSqlParam_ContactEmailId.Value as string;
               // objJobEntities.SkillsRequired = objSqlParam_SkillsRequired.Value as string;
               // objJobEntities.Qualification = objSqlParam_Qualification.Value as string;
               // objJobEntities.NoOfVacancies = Convert.ToInt32(objSqlParam_NoOfVaccancies.Value);
               // objJobEntities.YearsOfExperience = Convert.ToInt32(objSqlParam_YearsOfExperience.Value);

            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objJobEntities;
        }
        public JobEntities SearchAdminJobDAL(int id)  //Admin Search Job by id
        {
            JobEntities objJobEntities = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_AdminSearchJob]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                //SqlParameter objSqlParam_JobID = new SqlParameter("@JobID", SqlDbType.Int);
                //SqlParameter objSqlParameter_JobName = new SqlParameter("@JobName", SqlDbType.VarChar, 50);
                //SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", SqlDbType.VarChar, 30);
                //SqlParameter objSqlParam_Address = new SqlParameter("@Address", SqlDbType.VarChar, 25);
                //SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", SqlDbType.VarChar, 25);
                //SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", SqlDbType.VarChar, 100);
                //SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", SqlDbType.VarChar, 100);
                //SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", SqlDbType.VarChar, 50);
                //SqlParameter objSqlParam_Location = new SqlParameter("@Location", SqlDbType.VarChar,10);

                //SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", SqlDbType.Float);
                //SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", SqlDbType.Int);
                //SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", SqlDbType.Int);

                ////
                //objSqlParam_JobID.Direction = ParameterDirection.Input;
                //objSqlParameter_JobName.Direction = ParameterDirection.Output;
                //objSqlParam_Employer.Direction = ParameterDirection.Output;
                //objSqlParam_Address.Direction = ParameterDirection.Output;
                //objSqlParam_ContactNumber.Direction = ParameterDirection.Output;
                //objSqlParam_ContactEmailId.Direction = ParameterDirection.Output;
                //objSqlParam_SkillsRequired.Direction = ParameterDirection.Output;
                //objSqlParam_Qualification.Direction = ParameterDirection.Output;
                //objSqlParam_Location.Direction = ParameterDirection.Output;
                //objSqlParam_Salary.Direction = ParameterDirection.Output;
                //objSqlParam_NoOfVaccancies.Direction = ParameterDirection.Output;
                //objSqlParam_YearsOfExperience.Direction = ParameterDirection.Output;
                ////
                //objCom.Parameters.Add(objSqlParam_JobID);
                //objCom.Parameters.Add(objSqlParameter_JobName);
                //objCom.Parameters.Add(objSqlParam_Employer);
                //objCom.Parameters.Add(objSqlParam_Address);
                //objCom.Parameters.Add(objSqlParam_ContactNumber);
                //objCom.Parameters.Add(objSqlParam_ContactEmailId);
                //objCom.Parameters.Add(objSqlParam_SkillsRequired);
                //objCom.Parameters.Add(objSqlParam_Qualification);
                //objCom.Parameters.Add(objSqlParam_Location);
                //objCom.Parameters.Add(objSqlParam_Salary);
                //objCom.Parameters.Add(objSqlParam_NoOfVaccancies);
                //objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                ////

                ////
                //objCon.Open();
                //objCom.ExecuteNonQuery();
                //objJobEntities = new JobEntities();
                //// objJobEntities.JobID = id;
                //objJobEntities.JobName = objSqlParameter_JobName.Value as string;
                //objJobEntities.Employer = objSqlParam_Employer.Value as string;
                //objJobEntities.Address = objSqlParam_Address.Value as string;
                //objJobEntities.ContactNumber = objSqlParam_ContactNumber.Value as string;
                //objJobEntities.ContactEmailID = objSqlParam_ContactEmailId.Value as string;
                //objJobEntities.SkillsRequired = objSqlParam_SkillsRequired.Value as string;
                //objJobEntities.Qualification = objSqlParam_Qualification.Value as string;
                //objJobEntities.Location = objSqlParam_Location.Value as string;
                //objJobEntities.Salary = Convert.ToInt32(objSqlParam_Salary.Value);
                //objJobEntities.NoOfVacancies = Convert.ToInt32(objSqlParam_NoOfVaccancies.Value);
                //objJobEntities.YearsOfExperience = Convert.ToInt32(objSqlParam_YearsOfExperience.Value);

                objCom.Parameters.AddWithValue("@JobID", id);
                objCon.Open();
                objDR = objCom.ExecuteReader();
                objDR.Read();
                if(objDR.HasRows)
                {
                    objJobEntities = new JobEntities();
                    objJobEntities.JobID = Convert.ToInt32(objDR[0].ToString());
                    objJobEntities.JobName = objDR[1].ToString();
                    objJobEntities.Employer = objDR[2].ToString();
                    objJobEntities.Address = objDR[3].ToString();
                    objJobEntities.ContactNumber = objDR[4].ToString();
                    objJobEntities.ContactEmailID = objDR[5].ToString();
                    objJobEntities.SkillsRequired = objDR[6].ToString();
                    objJobEntities.Qualification = objDR[7].ToString();
                    objJobEntities.Location = objDR[8].ToString();
                    objJobEntities.Salary = Convert.ToInt32(objDR[9].ToString());
                    objJobEntities.NoOfVacancies = Convert.ToInt32(objDR[10].ToString());
                    objJobEntities.YearsOfExperience = Convert.ToInt32(objDR[10].ToString());
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objJobEntities;
        }

        public List<JobEntities> GetAllJobDAL() //to print all jobs for user and admin
        {
            List<JobEntities> objJobEntity = new List<JobEntities>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);   //change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_DisplayJobsUser]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    JobEntities objJobEntities = new JobEntities();
                    objJobEntities.JobID = Convert.ToInt32(objDR[0]);
                    objJobEntities.JobName = objDR[1] as string;
                    objJobEntities.Employer = objDR[2] as string;
                    objJobEntities.Location = objDR[8] as string;
                    objJobEntities.Address = objDR[3] as string;
                    objJobEntities.ContactEmailID = objDR[5] as string;
                    objJobEntities.ContactNumber = objDR[4] as string;
                    objJobEntities.SkillsRequired = objDR[6] as string;
                    objJobEntities.Qualification = objDR[7] as string;
                   
                    objJobEntities.NoOfVacancies = Convert.ToInt32(objDR[10]);
                    objJobEntities.Salary = Convert.ToInt32(objDR[9]);
                    objJobEntities.YearsOfExperience = Convert.ToInt32(objDR[11]);
                    objJobEntity.Add(objJobEntities);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objJobEntity;
        }

        public bool User(int id,string password)// tp validate user
        {
            bool validateuser = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                   ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_LoginUser]", objCon);//chnage
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@UserID", id);
                objCom.Parameters.AddWithValue("@Password", password);
                


                objCon.Open();
                objCom.ExecuteNonQuery();
                validateuser = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return validateuser;

        }


    }
}
